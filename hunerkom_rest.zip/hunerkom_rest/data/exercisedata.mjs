import Exercise from '../exercise.mjs'

const exercises = [
    new Exercise('Bench Press', 8, 165, 'lbs', '03-10-25'),
    new Exercise('Lat Pulldown', 10, 120, 'lbs', '03-10-25'),
    new Exercise('Squat', 8, 165, 'lbs', '03-10-25')
];

export default exercises;
